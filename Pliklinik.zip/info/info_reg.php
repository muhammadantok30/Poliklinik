<?php
    include"koneksi.php";
?>

        <div class="table table-responsive">
          <table class="table" width="100%">  
          <thead>
            <tr class="info">
            <h5>
              <th width="10%">No</th>
                
                <th width="20%">Tanggal pendaftaran</th>
                <th width="10%">No Urut</th>
                <th width="10%">NIP</th>
                <th width="20%">Kode Pasien</th>
                <th width="20%">Kode Jadwal</th>
                
               </b></h5>
              </tr>
            </thead>
            <tbody>
            <?php
            if (isset($_POST['btn_cari'])) {
              $cari=$_POST['txcari'];
              $no     =   1;
              $sql=mysql_query("SELECT * from tb_pendaftaran where no_pendaftaran like '%$cari%' or no_pas like '%$cari%'");
            }else{
              $no         =   1;
              $sql=mysql_query("select * from tb_pendaftaran ");
            }
            $ros=mysql_num_rows($sql);
            $ris=mysql_num_fields($sql);
                while ($row=mysql_fetch_array($sql, MYSQL_NUM)){
                ?>
                
                <tr>
                  <td><?php echo $no; ?></td>
                  
                  <td><?php echo $row[1] ?></td>
                  <td><?php echo $row[2] ?></td>
                  <td><?php echo $row[3] ?></td>
                  <td><?php echo $row[4] ?></td>
                  <td><?php echo $row[5] ?></td>
                                  
             <?php
              $no ++;
                 }
             ?>
             </tbody>
                </table>
                </div>   
            </div>
            </div>  
        </div>