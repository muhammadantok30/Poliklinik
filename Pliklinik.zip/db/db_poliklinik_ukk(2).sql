-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 28, 2016 at 01:49 
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_poliklinik_ukk`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `bayar`
--
CREATE TABLE IF NOT EXISTS `bayar` (
`nama_pas` varchar(50)
,`alamat_pas` varchar(100)
,`no_pendaftaran` int(11)
,`tanggal_reg` date
,`keluhan` varchar(100)
,`diagnosa` varchar(100)
,`tindakan` varchar(100)
,`dosis` varchar(30)
,`kode_rincian_resep` int(11)
,`nama_obat` varchar(50)
,`merk` varchar(30)
,`satuan` varchar(10)
,`tb_resep.jumlah=tb_obat.harga_jual` int(1)
,`harga_jual` int(10)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `cek_up`
--
CREATE TABLE IF NOT EXISTS `cek_up` (
`no_pendaftaran` int(11)
,`nip` varchar(10)
,`kode_pas` varchar(10)
,`kode_jadwal` varchar(10)
,`hari` varchar(10)
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `jadwal`
--
CREATE TABLE IF NOT EXISTS `jadwal` (
`nama_dok` varchar(50)
,`alamat_dok` varchar(100)
,`hari` varchar(10)
,`jam_mulai` time
,`jam_selesai` time
);
-- --------------------------------------------------------

--
-- Stand-in structure for view `pegawai`
--
CREATE TABLE IF NOT EXISTS `pegawai` (
`nip` varchar(10)
,`nama_peg` varchar(50)
,`alamat_peg` varchar(100)
,`telp_peg` varchar(12)
,`jenis_kelamin_peg` enum('Pria','Wanita')
,`type_user` varchar(20)
);
-- --------------------------------------------------------

--
-- Table structure for table `tb_dokter`
--

CREATE TABLE IF NOT EXISTS `tb_dokter` (
  `kode_dok` varchar(10) NOT NULL,
  `nama_dok` varchar(50) NOT NULL,
  `alamat_dok` varchar(100) NOT NULL,
  `telp_dok` varchar(12) NOT NULL,
  `kode_poli` varchar(10) NOT NULL,
  `kode_jadwal` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_dokter`
--

INSERT INTO `tb_dokter` (`kode_dok`, `nama_dok`, `alamat_dok`, `telp_dok`, `kode_poli`, `kode_jadwal`) VALUES
('DOKTER0001', 'Dr.Muhammad Antok', 'Lasem', '083843198432', 'POLI000001', 'JDWAL00001'),
('DOKTER0002', 'Dr.Wardi Handoko', 'Rembang', '082309832100', 'POLI000003', 'JDWAL00002'),
('DOKTER0003', 'dfghjk', 'wertyuio', '34567', 'POLI000004', 'JDWAL00003');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jadwal_praktik`
--

CREATE TABLE IF NOT EXISTS `tb_jadwal_praktik` (
  `kode_jadwal` varchar(10) NOT NULL,
  `hari` varchar(10) NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jadwal_praktik`
--

INSERT INTO `tb_jadwal_praktik` (`kode_jadwal`, `hari`, `jam_mulai`, `jam_selesai`) VALUES
('JDWAL00001', 'Senin', '07:00:00', '19:00:00'),
('JDWAL00002', 'Selasa', '08:00:00', '20:00:00'),
('JDWAL00003', 'Rabu', '08:00:00', '18:00:00'),
('JDWAL00004', 'senin', '07:00:00', '18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jenis_biaya`
--

CREATE TABLE IF NOT EXISTS `tb_jenis_biaya` (
  `kode_jenis_biaya` varchar(10) NOT NULL,
  `nama_biaya` varchar(30) NOT NULL,
  `tarif` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_jenis_biaya`
--

INSERT INTO `tb_jenis_biaya` (`kode_jenis_biaya`, `nama_biaya`, `tarif`) VALUES
('JSBYA00001', 'Cabut gigi', 300000),
('JSBYA00002', 'Periksa mata', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_login`
--

CREATE TABLE IF NOT EXISTS `tb_login` (
  `username` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `password` varchar(40) NOT NULL,
  `type_user` varchar(20) NOT NULL,
  `nip` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_login`
--

INSERT INTO `tb_login` (`username`, `password`, `type_user`, `nip`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'PEG0000002'),
('asisten', 'bf3fd5c967c0fb904bf15c054e4288dd', 'asisten', 'PEG0000003'),
('kasir', 'c7911af3adbd12a035b289556d96470a', 'kasir', 'PEG0000001'),
('reg', '33c0ee425e2c0efe834afc1aa1e33a4c', 'pendaftar', 'PEG0000005');

-- --------------------------------------------------------

--
-- Table structure for table `tb_obat`
--

CREATE TABLE IF NOT EXISTS `tb_obat` (
  `kode_obat` varchar(10) NOT NULL,
  `nama_obat` varchar(50) NOT NULL,
  `merk` varchar(30) NOT NULL,
  `satuan` varchar(10) NOT NULL,
  `harga_jual` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_obat`
--

INSERT INTO `tb_obat` (`kode_obat`, `nama_obat`, `merk`, `satuan`, `harga_jual`) VALUES
('OBAT000001', 'Antialergi', 'Crolag', 'Tablet', 5000),
('OBAT000002', 'Antipirai', 'Acetosal', 'Botol', 25000),
('OBAT000003', 'Antimigrain', 'Ergotamin', 'Kapsul', 4000),
('OBAT000004', 'Antiseptik', 'Etoposid', 'Botol', 15000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pasien`
--

CREATE TABLE IF NOT EXISTS `tb_pasien` (
  `kode_pas` varchar(10) NOT NULL,
  `nama_pas` varchar(50) NOT NULL,
  `alamat_pas` varchar(100) NOT NULL,
  `telp_pas` varchar(12) NOT NULL,
  `tanggal_lahir_pas` date NOT NULL,
  `jenis_kelamin_pas` enum('Pria','Wanita') NOT NULL,
  `tanggal_reg` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pasien`
--

INSERT INTO `tb_pasien` (`kode_pas`, `nama_pas`, `alamat_pas`, `telp_pas`, `tanggal_lahir_pas`, `jenis_kelamin_pas`, `tanggal_reg`) VALUES
('PASEN00001', 'Kurniawan Mega', 'Lasem', '087773826344', '1999-02-10', 'Pria', '2016-02-25'),
('PASEN00002', 'Diki Andri', 'Pancur', '089773774821', '2010-02-03', 'Pria', '2016-02-25'),
('PASEN00003', 'Doni', 'Lasem', '098889992882', '1998-06-11', 'Pria', '2016-02-27'),
('PASEN00004', 'Juni', 'Rembang', '089992883449', '2016-02-09', 'Wanita', '2016-02-27');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pegawai`
--

CREATE TABLE IF NOT EXISTS `tb_pegawai` (
  `nip` varchar(10) NOT NULL,
  `nama_peg` varchar(50) NOT NULL,
  `alamat_peg` varchar(100) NOT NULL,
  `telp_peg` varchar(12) NOT NULL,
  `jenis_kelamin_peg` enum('Pria','Wanita') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pegawai`
--

INSERT INTO `tb_pegawai` (`nip`, `nama_peg`, `alamat_peg`, `telp_peg`, `jenis_kelamin_peg`) VALUES
('PEG0000001', 'Muhammad Antok', 'Lasem', '087717556187', 'Pria'),
('PEG0000002', 'Roni Binjai', 'Balikpapan', '089776358653', 'Pria'),
('PEG0000003', 'Raisha Subandhono', 'Semarang', '087717556122', 'Wanita'),
('PEG0000004', 'Sandi Rikmanto', 'Subang', '084776638099', 'Pria'),
('PEG0000005', 'Joko Suseno', 'Rembang', '089883654783', 'Pria'),
('PEG0000006', 'Siti Andriani', 'Lasem', '082331599485', 'Wanita'),
('PEG0000008', 'Nanik', 'Ropoh', '082559431998', 'Wanita');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pemeriksaan`
--

CREATE TABLE IF NOT EXISTS `tb_pemeriksaan` (
  `kode_pemeriksaan` varchar(10) NOT NULL,
  `keluhan` varchar(100) NOT NULL,
  `diagnosa` varchar(100) NOT NULL,
  `perawatan` varchar(100) NOT NULL,
  `tindakan` varchar(100) NOT NULL,
  `berat_badan` int(5) NOT NULL,
  `tensi_diastolik` int(5) NOT NULL,
  `tensi_sistolik` int(5) NOT NULL,
  `no_pendaftaran` int(11) NOT NULL,
  `kode_resep` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pemeriksaan`
--

INSERT INTO `tb_pemeriksaan` (`kode_pemeriksaan`, `keluhan`, `diagnosa`, `perawatan`, `tindakan`, `berat_badan`, `tensi_diastolik`, `tensi_sistolik`, `no_pendaftaran`, `kode_resep`) VALUES
('PRSK000001', 'Demam, Muntah', 'Tipes', 'Makan dan Minum Teratur', 'Minum Obat Teratur', 67, 100, 90, 1, 'RESEP00002'),
('PRSK000002', 'Batuk', 'Radang Tenggorokan', 'Makan dan Minum Teratur', 'Minum Obat Teratur', 55, 90, 94, 2, 'RESEP00003');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pendaftaran`
--

CREATE TABLE IF NOT EXISTS `tb_pendaftaran` (
`no_pendaftaran` int(11) NOT NULL,
  `tanggal_reg` date NOT NULL,
  `no_urut` int(11) NOT NULL,
  `nip` varchar(10) NOT NULL,
  `kode_pas` varchar(10) NOT NULL,
  `kode_jadwal` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_pendaftaran`
--

INSERT INTO `tb_pendaftaran` (`no_pendaftaran`, `tanggal_reg`, `no_urut`, `nip`, `kode_pas`, `kode_jadwal`) VALUES
(1, '2016-02-25', 1, 'PEG0000001', 'PASEN00001', 'JDWAL00001'),
(2, '2016-02-25', 2, 'PEG0000001', 'PASEN00002', 'JDWAL00001');

-- --------------------------------------------------------

--
-- Table structure for table `tb_poliklinik`
--

CREATE TABLE IF NOT EXISTS `tb_poliklinik` (
  `kode_poli` varchar(10) NOT NULL,
  `nama_poli` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_poliklinik`
--

INSERT INTO `tb_poliklinik` (`kode_poli`, `nama_poli`) VALUES
('POLI000001', 'Poli Syaraf'),
('POLI000002', 'Poli Kandungan'),
('POLI000003', 'Poli Gigi'),
('POLI000004', 'Poli THT'),
('POLI09', 'okoko');

-- --------------------------------------------------------

--
-- Table structure for table `tb_resep`
--

CREATE TABLE IF NOT EXISTS `tb_resep` (
  `kode_resep` varchar(10) NOT NULL,
  `dosis` varchar(30) NOT NULL,
  `jumlah` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_resep`
--

INSERT INTO `tb_resep` (`kode_resep`, `dosis`, `jumlah`) VALUES
('RESEP00001', '3 x 1 / hari', 6),
('RESEP00002', '2 x 1 / hari', 4),
('RESEP00003', '2 x 1 / hari', 6);

-- --------------------------------------------------------

--
-- Table structure for table `tb_rincian_jenis_biaya`
--

CREATE TABLE IF NOT EXISTS `tb_rincian_jenis_biaya` (
`kode_rincian_biaya` int(11) NOT NULL,
  `no_pendaftaran` int(11) NOT NULL,
  `kode_jenis_biaya` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_rincian_jenis_biaya`
--

INSERT INTO `tb_rincian_jenis_biaya` (`kode_rincian_biaya`, `no_pendaftaran`, `kode_jenis_biaya`) VALUES
(1, 1, 'JSBYA00002'),
(2, 2, 'JSBYA00001');

-- --------------------------------------------------------

--
-- Table structure for table `tb_rincian_resep`
--

CREATE TABLE IF NOT EXISTS `tb_rincian_resep` (
`kode_rincian_resep` int(11) NOT NULL,
  `kode_resep` varchar(10) NOT NULL,
  `kode_obat` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_rincian_resep`
--

INSERT INTO `tb_rincian_resep` (`kode_rincian_resep`, `kode_resep`, `kode_obat`) VALUES
(1, 'RESEP00001', 'OBAT000001'),
(2, 'RESEP00001', 'OBAT000002');

-- --------------------------------------------------------

--
-- Table structure for table `tb_transaksi`
--

CREATE TABLE IF NOT EXISTS `tb_transaksi` (
`id_trans` int(10) NOT NULL,
  `kode_jadwal` varchar(10) NOT NULL,
  `nomer_reg` varchar(10) NOT NULL,
  `nama_pasien` varchar(50) NOT NULL,
  `keluhan` text NOT NULL,
  `diagnosa` varchar(100) NOT NULL,
  `perawatan` varchar(100) NOT NULL,
  `kode_resep` varchar(10) NOT NULL,
  `nama_obat` varchar(30) NOT NULL,
  `dosis` varchar(10) NOT NULL,
  `harga_jual` int(10) NOT NULL,
  `jumlah` int(5) NOT NULL,
  `total` int(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_transaksi`
--

INSERT INTO `tb_transaksi` (`id_trans`, `kode_jadwal`, `nomer_reg`, `nama_pasien`, `keluhan`, `diagnosa`, `perawatan`, `kode_resep`, `nama_obat`, `dosis`, `harga_jual`, `jumlah`, `total`) VALUES
(1, 'JDWAL00001', '1', 'Kurniawan Mega', 'Demam, Muhtah', 'Tipes', 'Makan dan Minum Obat Teratur', 'RESEP00002', 'Antiseptik', '3 x 1/hari', 15000, 6, 90000);

-- --------------------------------------------------------

--
-- Structure for view `bayar`
--
DROP TABLE IF EXISTS `bayar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bayar` AS select `tb_pasien`.`nama_pas` AS `nama_pas`,`tb_pasien`.`alamat_pas` AS `alamat_pas`,`tb_pendaftaran`.`no_pendaftaran` AS `no_pendaftaran`,`tb_pendaftaran`.`tanggal_reg` AS `tanggal_reg`,`tb_pemeriksaan`.`keluhan` AS `keluhan`,`tb_pemeriksaan`.`diagnosa` AS `diagnosa`,`tb_pemeriksaan`.`tindakan` AS `tindakan`,`tb_resep`.`dosis` AS `dosis`,`tb_rincian_resep`.`kode_rincian_resep` AS `kode_rincian_resep`,`tb_obat`.`nama_obat` AS `nama_obat`,`tb_obat`.`merk` AS `merk`,`tb_obat`.`satuan` AS `satuan`,(`tb_resep`.`jumlah` = `tb_obat`.`harga_jual`) AS `tb_resep.jumlah=tb_obat.harga_jual`,`tb_obat`.`harga_jual` AS `harga_jual` from (((((`tb_pasien` join `tb_pendaftaran`) join `tb_pemeriksaan`) join `tb_resep`) join `tb_rincian_resep`) join `tb_obat`) where (`tb_pasien`.`kode_pas` = `tb_pendaftaran`.`kode_pas`);

-- --------------------------------------------------------

--
-- Structure for view `cek_up`
--
DROP TABLE IF EXISTS `cek_up`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `cek_up` AS select `tb_pendaftaran`.`no_pendaftaran` AS `no_pendaftaran`,`tb_pendaftaran`.`nip` AS `nip`,`tb_pendaftaran`.`kode_pas` AS `kode_pas`,`tb_jadwal_praktik`.`kode_jadwal` AS `kode_jadwal`,`tb_jadwal_praktik`.`hari` AS `hari` from (`tb_pendaftaran` join `tb_jadwal_praktik`) where (`tb_pendaftaran`.`kode_jadwal` = `tb_jadwal_praktik`.`kode_jadwal`);

-- --------------------------------------------------------

--
-- Structure for view `jadwal`
--
DROP TABLE IF EXISTS `jadwal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `jadwal` AS select `tb_dokter`.`nama_dok` AS `nama_dok`,`tb_dokter`.`alamat_dok` AS `alamat_dok`,`tb_jadwal_praktik`.`hari` AS `hari`,`tb_jadwal_praktik`.`jam_mulai` AS `jam_mulai`,`tb_jadwal_praktik`.`jam_selesai` AS `jam_selesai` from (`tb_dokter` join `tb_jadwal_praktik`) where (`tb_dokter`.`kode_jadwal` = `tb_jadwal_praktik`.`kode_jadwal`);

-- --------------------------------------------------------

--
-- Structure for view `pegawai`
--
DROP TABLE IF EXISTS `pegawai`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pegawai` AS select `tb_pegawai`.`nip` AS `nip`,`tb_pegawai`.`nama_peg` AS `nama_peg`,`tb_pegawai`.`alamat_peg` AS `alamat_peg`,`tb_pegawai`.`telp_peg` AS `telp_peg`,`tb_pegawai`.`jenis_kelamin_peg` AS `jenis_kelamin_peg`,`tb_login`.`type_user` AS `type_user` from (`tb_pegawai` join `tb_login`) where (`tb_login`.`nip` = `tb_pegawai`.`nip`);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_dokter`
--
ALTER TABLE `tb_dokter`
 ADD PRIMARY KEY (`kode_dok`), ADD KEY `kode_poli` (`kode_poli`), ADD KEY `kode_jadwal` (`kode_jadwal`);

--
-- Indexes for table `tb_jadwal_praktik`
--
ALTER TABLE `tb_jadwal_praktik`
 ADD PRIMARY KEY (`kode_jadwal`);

--
-- Indexes for table `tb_jenis_biaya`
--
ALTER TABLE `tb_jenis_biaya`
 ADD PRIMARY KEY (`kode_jenis_biaya`);

--
-- Indexes for table `tb_login`
--
ALTER TABLE `tb_login`
 ADD PRIMARY KEY (`username`), ADD KEY `nip` (`nip`), ADD KEY `nip_2` (`nip`), ADD KEY `nip_3` (`nip`);

--
-- Indexes for table `tb_obat`
--
ALTER TABLE `tb_obat`
 ADD PRIMARY KEY (`kode_obat`);

--
-- Indexes for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
 ADD PRIMARY KEY (`kode_pas`);

--
-- Indexes for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
 ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `tb_pemeriksaan`
--
ALTER TABLE `tb_pemeriksaan`
 ADD PRIMARY KEY (`kode_pemeriksaan`), ADD KEY `no_pendaftaran` (`no_pendaftaran`,`kode_resep`), ADD KEY `kode_resep` (`kode_resep`);

--
-- Indexes for table `tb_pendaftaran`
--
ALTER TABLE `tb_pendaftaran`
 ADD PRIMARY KEY (`no_pendaftaran`), ADD KEY `nip` (`nip`,`kode_pas`,`kode_jadwal`), ADD KEY `kode_jadwal` (`kode_jadwal`), ADD KEY `kode_pas` (`kode_pas`);

--
-- Indexes for table `tb_poliklinik`
--
ALTER TABLE `tb_poliklinik`
 ADD PRIMARY KEY (`kode_poli`);

--
-- Indexes for table `tb_resep`
--
ALTER TABLE `tb_resep`
 ADD PRIMARY KEY (`kode_resep`);

--
-- Indexes for table `tb_rincian_jenis_biaya`
--
ALTER TABLE `tb_rincian_jenis_biaya`
 ADD PRIMARY KEY (`kode_rincian_biaya`), ADD KEY `no_pendaftaran` (`no_pendaftaran`,`kode_jenis_biaya`), ADD KEY `kode_jenis_biaya` (`kode_jenis_biaya`);

--
-- Indexes for table `tb_rincian_resep`
--
ALTER TABLE `tb_rincian_resep`
 ADD PRIMARY KEY (`kode_rincian_resep`), ADD KEY `kode_resep` (`kode_resep`,`kode_obat`), ADD KEY `kode_obat` (`kode_obat`), ADD KEY `kode_resep_2` (`kode_resep`,`kode_obat`);

--
-- Indexes for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
 ADD PRIMARY KEY (`id_trans`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_pendaftaran`
--
ALTER TABLE `tb_pendaftaran`
MODIFY `no_pendaftaran` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_rincian_jenis_biaya`
--
ALTER TABLE `tb_rincian_jenis_biaya`
MODIFY `kode_rincian_biaya` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_rincian_resep`
--
ALTER TABLE `tb_rincian_resep`
MODIFY `kode_rincian_resep` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_transaksi`
--
ALTER TABLE `tb_transaksi`
MODIFY `id_trans` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_dokter`
--
ALTER TABLE `tb_dokter`
ADD CONSTRAINT `tb_dokter_ibfk_2` FOREIGN KEY (`kode_jadwal`) REFERENCES `tb_jadwal_praktik` (`kode_jadwal`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `tb_dokter_ibfk_3` FOREIGN KEY (`kode_poli`) REFERENCES `tb_poliklinik` (`kode_poli`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_login`
--
ALTER TABLE `tb_login`
ADD CONSTRAINT `tb_login_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `tb_pegawai` (`nip`);

--
-- Constraints for table `tb_pemeriksaan`
--
ALTER TABLE `tb_pemeriksaan`
ADD CONSTRAINT `tb_pemeriksaan_ibfk_2` FOREIGN KEY (`kode_resep`) REFERENCES `tb_resep` (`kode_resep`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `tb_pemeriksaan_ibfk_3` FOREIGN KEY (`no_pendaftaran`) REFERENCES `tb_pendaftaran` (`no_pendaftaran`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_pendaftaran`
--
ALTER TABLE `tb_pendaftaran`
ADD CONSTRAINT `tb_pendaftaran_ibfk_3` FOREIGN KEY (`kode_jadwal`) REFERENCES `tb_jadwal_praktik` (`kode_jadwal`) ON UPDATE CASCADE,
ADD CONSTRAINT `tb_pendaftaran_ibfk_5` FOREIGN KEY (`nip`) REFERENCES `tb_pegawai` (`nip`) ON UPDATE CASCADE,
ADD CONSTRAINT `tb_pendaftaran_ibfk_6` FOREIGN KEY (`kode_pas`) REFERENCES `tb_pasien` (`kode_pas`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_rincian_jenis_biaya`
--
ALTER TABLE `tb_rincian_jenis_biaya`
ADD CONSTRAINT `tb_rincian_jenis_biaya_ibfk_2` FOREIGN KEY (`kode_jenis_biaya`) REFERENCES `tb_jenis_biaya` (`kode_jenis_biaya`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `tb_rincian_jenis_biaya_ibfk_3` FOREIGN KEY (`no_pendaftaran`) REFERENCES `tb_pendaftaran` (`no_pendaftaran`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tb_rincian_resep`
--
ALTER TABLE `tb_rincian_resep`
ADD CONSTRAINT `tb_rincian_resep_ibfk_1` FOREIGN KEY (`kode_obat`) REFERENCES `tb_obat` (`kode_obat`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `tb_rincian_resep_ibfk_2` FOREIGN KEY (`kode_resep`) REFERENCES `tb_resep` (`kode_resep`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
