<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">
                            Employee Data
                    </h2>
                </div>
            </div>
<div class="panel panel-info">
  <div class="panel-heading"><center>Edit Employee</center></div>
      <div class="panel-body"> 
        <?php
            include"../../koneksi.php";
        ?>
            <?php
                if (isset($_GET['ubah'])) {
                    $Kode=$_GET['ubah'];
                    $sql=mysql_query("select * from tb_pegawai where nip='$Kode'");
                    $tampil=mysql_fetch_array($sql);
            ?> 
        <form method="post">           
            <label class="control-label for="inputSuccess4"">
                NIP
            </label>
                <input type="text" class="form-control" value="<?php echo $tampil['0']?>" readonly>
                <input type="hidden" name="nip" value="<?php echo $tampil['0']?>">   
            </p>
            <label class="control-label for="inputSuccess4"">
                Name 
            </label>
                <input type="text" class="form-control" name="nm_pegawai" value="<?php echo $tampil['1']?>">
            </p>
            <label class="control-label for="inputSuccess4"">
                Address 
            </label>
                <input type="text" class="form-control" name="alamat_peg" value="<?php echo $tampil['2']?>">
            </p>
            <label class="control-label for="inputSuccess4"">
                Phone 
            </label>
                <input type="text" class="form-control" name="telepon" value="<?php echo $tampil['3']?>">
            </p>
            </label>
                <br>
                 <input type="radio" name="jk_peg" value="L" id="lakilaki" required>
                    <label for="lakilaki">Man</label>
                <input type="radio" name="jk_peg" value="P" id="perempuan" required>
                    <label for="perempuan">Woman</label>
            </p>   
        
            <label></label>
            </p>
             <input type="submit" name="edit" value="Edit" class=" btn btn-success">
            <a href="?page=pegawai_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
         <?php
            }
            if (isset($_POST['edit'])) {
                $nip=$_POST['nip'];
                $nama=$_POST['nm_pegawai'];
                $alamat=$_POST['alamat_peg'];
                $tlp=$_POST['telepon'];
                $jk=$_POST['jk_peg'];
                
                $query=mysql_query("UPDATE tb_pegawai SET  nip =  '$nip', nama_peg =  '$nama', alamat_peg =  '$alamat',  telp_peg =  '$tlp', jenis_kelamin_peg =  '$jk' WHERE  nip =  '$nip'");
                if($query){
                    echo'<script>alert("Data Berhasil Di Update");
                    window.location.assign("?page=pegawai_view");</script>';
                }else{
                    echo'<script>alert("Data Gagal Di Update");</script>';
                }
            }
            ?>
 </div>                                 
</div>