<?php
include "../koneksi.php";
?>

<?php
  $query_oto = mysql_query("select max(nip) as maks from tb_pegawai");
  $data_oto = mysql_fetch_array($query_oto);
  $data_auto = substr($data_oto['maks'],3,7);
  $data_auto++;
  $koded="";
  for ($i=strlen($data_auto); $i <=5 ; $i++)
    $koded = $koded."0";
    $data['nip'] = "PEG$koded$data_auto";

?>
    <?php
    if (isset($_POST['tambah'])) {
        $nip=$_POST['nip'];
        $nama=$_POST['nama'];      
        $alamat=$_POST['alamat'];
        $tlp=$_POST['telepon'];
        $jk=$_POST['jk_oeg'];       

        $sql=mysql_query("insert into tb_pegawai values ('$nip', '$nama', '$alamat', '$tlp', '$jk')");            
            if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=pegawai_view");</script>';
            }else{
                echo'<script>alert("Data Gagal Di Tambah);</script>';           
         }
        }
    ?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Create</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading"><center> Add Employee</center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"">
                NIP
            </label>
                <input type="text" name="nip" value="<?php echo $data['nip'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Nama 
            </label>
                <input type="text" class="form-control" name="nama" required>
            </p>
            <label class="control-label for="inputSuccess4"">
                Alamat 
            </label>
                <input type="text" class="form-control" name="alamat" required>
            </p>
            <label class="control-label for="inputSuccess4"">
                Telepon 
            </label>
                <input type="text" class="form-control" name="telepon" required>
            </p>
            <label class="control-label for="inputSuccess4"">
                Jenis Kelamin 
            </label>
            <br>
            <input type="radio" name="jk_peg" value="Pria" id="Pria" required>
                    <label for="Pria">Pria</label>
                <input type="radio" name="jk_peg" value="Wanita" id="Wanita" required>
                    <label for="Wanita">Wanita</label>
            </p>        
             
            <label></label>
            
            <input type="submit" name="tambah" value="Create" class=" btn btn-success">
            <a href="?page=pegawai_view"><button type="button" class="btn btn-warning"><span class="glyphicon glyphicon-repeat"></span> Cancel</button></a>
        </form>
    </div>
    </div>
</div>  