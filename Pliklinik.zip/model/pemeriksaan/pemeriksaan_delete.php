<?php
include"../koneksi.php";
?>
<?php
if (isset($_GET['delete'])) {
		$id			=	$_GET['delete'];

		$delete 	=	mysql_query("DELETE FROM tb_pemeriksaan WHERE kode_pemeriksaan = '$id'");
		if ($delete) {
			echo "<meta http-equiv='refresh' content='0;URL= ?page=pemeriksaan_view'/>";
		}
	}
	?>