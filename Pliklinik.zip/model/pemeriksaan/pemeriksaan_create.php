<?php
include "../koneksi.php";
?>
    <?php
    if (isset($_POST['tambah'])) {
        $kode=$_POST['no'];
        $keluhan=$_POST['keluhan'];
        $diagnosa=$_POST['diagnosa'];
        $perawatan=$_POST['perawatan'];
        $tindakan=$_POST['tindakan'];
        $bb=$_POST['bb'];
        $td=$_POST['tensi_diagnosis'];
        $ts=$_POST['tensi_sistolik'];
        $nrs=$_POST['no_resep'];
        $nr=$_POST['no_reg'];
        $sql=mysql_query("insert into tb_pemeriksaan values ('$kode', '$keluhan', '$diagnosa', '$perawatan', '$tindakan', '$bb', '$td', '$ts', '$nrs', '$nr')");            
            if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=pemeriksaan_view");</script>';
            }else{
                echo'<script>alert("Data Gagal Di Tambah);</script>';           
         }
        }
    ?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Create</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading"><center> Tambah Data Jadwal</center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"">
                No Pemeriksaan
            </label>
                <input type="text" name="no" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Keluhan
            </label>
                <input type="text" name="keluhan" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Diagnosa
            </label>
                <input type="text" name="diagnosa" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Perwatan
            </label>
                <input type="text" name="perawatan" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Tindakan
            </label>
                <input type="text" name="tindakan" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                BB
            </label>
                <input type="text" name="bb" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Tensi Diagnosis
            </label>
                <input type="text" name="tensi_diagnosis" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Tensi Sistolik
            </label>
                <input type="text" name="tensi_sistolik" class="form-control" required>   
            </p>
            <label class="control-label for="inputSuccess4"">
                No Resep
                </p>
                    <select class="form-control" name="no_resep" id="no_resep">
                        <option value=""></option>
                            <?php
                                $query_pemeriksaan = mysql_query("SELECT kode_resep FROM tb_resep");
                                while ($data = mysql_fetch_array($query_pemeriksaan)) {
                                    # condition..
                                    if  ($query_pemeriksaan==$data['kode_resep']) {
                                        echo "<option value=$data[kode_resep] selected>$data[kode_resep]</option>";
                                        # code..
                                    }
                                        # code..
                                    else{
                                        echo "<option value=$data[kode_resep]>$data[kode_resep]</option>";
                                    }
                                }
                            ?>
                    </select>
                 </p>
            <label class="control-label for="inputSuccess4"">
                No Pendaftaran
                </p>
                    <select class="form-control" name="no_reg" id="no_reg">
                        <option value=""></option>
                            <?php
                                $query_pendaftaran = mysql_query("SELECT no_pendaftaran FROM tb_pendaftaran");
                                while ($data2 = mysql_fetch_array($query_pendaftaran)) {
                                    # condition..
                                    if  ($query_pendaftaran==$data2['no_pendaftaran']) {
                                        echo "<option value=$data2[no_pendaftaran] selected>$data2[no_pendaftaran]</option>";
                                        # code..
                                    }
                                        # code..
                                    else{
                                        echo "<option value=$data2[no_pendaftaran]>$data2[no_pendaftaran]</option>";
                                    }
                                }
                            ?>
                    </select>
                 </p>
            <label></label>
            
            <input type="submit" name="tambah" value="Create" class=" btn btn-success">
            <a href="?page=pemeriksaan_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
    </div>
    </div>
</div>