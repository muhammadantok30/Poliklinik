<?php
include "../koneksi.php";
?>
    <?php
    if (isset($_POST['tambah'])) {
        $no=$_POST['no'];
        $tgl=$_POST['tanggal'];
        $nourut=$_POST['no_urut'];
        $nip=$_POST['nip'];
        $no_pas=$_POST['no_pas'];
        $jadwal=$_POST['no_jadwal'];
        $sql=mysql_query("insert into tb_pendaftaran values ('$no', '$tgl', '$nourut', '$nip', '$no_pas', '$jadwal')");            
            if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=pendaftaran_view");</script>';
            }else{
                echo'<script>alert("Data Gagal Di Tambah);</script>';           
         }
        }
    ?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Create</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading"><center> Tambah Pendaftaran</center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"" required>
                No Pendaftaran
            </label>
                <input type="text" name="no" placeholder="Tidak Perlu Diisi" class="form-control" readonly>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Tanggal Daftar
            </label>
                <input type="date" name="tanggal" placeholder="yyyy-MM-dd" class="form-control" required>   
            </p>
            <label class="control-label for="inputSuccess4"">
                No Daftar
            </label>
                <input type="text" name="no_urut" class="form-control" required>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Kode Pegawai
                </p>
                    <select class="form-control" name="nip" id="nip">
                        <option value=""></option>
                            <?php
                                $query_pendaftaran = mysql_query("SELECT nip FROM tb_login WHERE type_user = 'pendaftar' ");
                                while ($data = mysql_fetch_array($query_pendaftaran)) {
                                    # condition..
                                    if  ($query_pendaftaran==$data['nip']) {
                                        echo "<option value=$data[nip] selected>$data[nip]</option>";
                                        # code..
                                    }
                                        # code..
                                    else{
                                        echo "<option value=$data[nip]>$data[nip]</option>";
                                    }
                                }
                            ?>
                    </select>
                 </p>
            <label class="control-label for="inputSuccess4"">
                kode Pasien
                </p>
                    <select class="form-control" name="no_pas" id="no_pas">
                        <option value=""></option>
                            <?php
                                $query_pendaftaran = mysql_query("SELECT kode_pas FROM tb_pasien");
                                while ($data2 = mysql_fetch_array($query_pendaftaran)) {
                                    # condition..
                                    if  ($query_pendaftaran==$data2['kode_pas']) {
                                        echo "<option value=$data2[kode_pas] selected>$data2[kode_pas]</option>";
                                        # code..
                                    }
                                        # code..
                                    else{
                                        echo "<option value=$data2[kode_pas]>$data2[kode_pas]</option>";
                                    }
                                }
                            ?>
                    </select>
                 </p>
            <label class="control-label for="inputSuccess4"">
                Kode Jadwal
                </p>
                    <select class="form-control" name="no_jadwal" id="no_jadwal">
                        <option value=""></option>
                            <?php
                                $query_pendaftaran = mysql_query("SELECT kode_jadwal FROM tb_jadwal_praktik");
                                while ($data3 = mysql_fetch_array($query_pendaftaran)) {
                                    # condition..
                                    if  ($query_pendaftaran==$data3['kode_jadwal']) {
                                        echo "<option value=$data3[kode_jadwal] selected>$data3[kode_jadwal]</option>";
                                        # code..
                                    }
                                        # code..
                                    else{
                                        echo "<option value=$data3[kode_jadwal]>$data3[kode_jadwal]</option>";
                                    }
                                }
                            ?>
                    </select>
                 </p>
            <label></label>
            
            <input type="submit" name="tambah" value="Create" class=" btn btn-success">
            <a href="?page=reg_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
    </div>
    </div>
</div>