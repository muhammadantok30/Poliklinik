<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">
                            Data Poli
                    </h2>
                </div>
            </div>
<div class="panel panel-info">
  <div class="panel-heading"><center>Ubah Data Poli</center></div>
      <div class="panel-body"> 
        <?php
            include"../koneksi.php";
        ?>
            <?php
                if (isset($_GET['ubah'])) {
                    $Kode=$_GET['ubah'];
                    $sql=mysql_query("select * from tb_poliklinik where kode_poli='$Kode'");
                    $tampil=mysql_fetch_array($sql);
            ?> 
        <form method="post">           
            <label class="control-label for="inputSuccess4"">
                Kode Jadwal
            </label>
                <input type="text" class="form-control" value="<?php echo $tampil['0']?>" readonly>
                <input type="hidden" name="kode_poli" value="<?php echo $tampil['0']?>">   
            </p>
            <label class="control-label for="inputSuccess4"">
                Jenis Poli 
            </label>
                <input type="text" class="form-control" name="nama_poli" value="<?php echo $tampil['1']?>">
            <label></label>
            </p>
             <input type="submit" name="edit" value="Edit" class=" btn btn-success">
            <a href="?page=poli_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
         <?php
            }
            if (isset($_POST['edit'])) {
                $kode=$_POST['kode_poli'];
                $hari=$_POST['nama_poli'];
                                
                $query=mysql_query("UPDATE tb_poliklinik SET  kode_poli =  '$kode', nama_poli =  '$hari' WHERE  kode_poli =  '$kode'");
                if($query){
                    echo'<script>alert("Data Berhasil Di Update");
                    window.location.assign("?page=poli_view");</script>';
                }else{
                    echo'<script>alert("Data Gagal Di Update");</script>';
                }
            }
            ?>
 </div>                                 
</div>