<?php
	include ("../../koneksi.php");
	require ("../../fpdf/fpdf.php");
	$pdf = new FPDF();
	$pdf -> AddPage();

	$pdf->SetFont('Arial','B',18);
	$pdf->Cell(0,8,"Laporan Rekam Medis","0","6","C",false);
	$pdf->Ln(3);
	$pdf->Cell(190,0.6,'','0','1','c',true);
	$pdf->Ln(5);

	$pdf->SetFont('Arial','B',9);
	$pdf->Cell(35,6,'NIP',1,0,'C');
	$pdf->Cell(35,6,'Nama',1,0,'C');
	$pdf->Cell(35,6,'Alamat',1,0,'C');
	$pdf->Cell(35,6,'Telepon',1,0,'C');
	$pdf->Cell(35,6,'Jenis Kelamin',1,0,'C');
	
	$pdf->Ln(2);
	if (isset($_POST['print'])) {
		$dari=$_POST['dari'];
		$sd=$_POST['sampai'];
		$sql=mysql_query("SELECT * FROM tb_pegawai where nip BETWEEN '$dari' AND '$sd' ");
	}
	while ($data = mysql_fetch_array($sql)) {
		$pdf->Ln(4);
		$pdf->SetFont('Arial','',7);
		$pdf->Cell(35,4,$data['nip'],1,0,'L');
		$pdf->Cell(35,4,$data['nama_peg'],1,0,'L');
		$pdf->Cell(35,4,$data['alamat_peg'],1,0,'L');
		$pdf->Cell(35,4,$data['telp_peg'],1,0,'L');
		$pdf->Cell(35,4,$data['jenis_kelamin_peg'],1,0,'L');
		
	}
	$pdf->Output();

?>