<?php
include "../koneksi.php";
?>
<?php
  $query_oto = mysql_query("select max(kode_dok) as maks from tb_dokter");
  $data_oto = mysql_fetch_array($query_oto);
  $data_auto = substr($data_oto['maks'],6,4);
  $data_auto++;
  $koded="";
  for ($i=strlen($data_auto); $i <=3 ; $i++)
    $koded = $koded."0";
    $data['kode_dok'] = "DOKTER$koded$data_auto";

?>

    <?php
    if (isset($_POST['tambah'])) {
        $kode=$_POST['kode'];
        $nama=$_POST['nama'];
        $adr =$_POST['alamat'];
        $telp=$_POST['telp'];
        $kp  =$_POST['kode_poli'];
        $kj  =$_POST['kode_jadwal'];
        
        if ($kode == "" || $nama == "" || $adr == "" || $telp == "" || $kp == "" ||  $kj == "") {
          echo '<script>alert("Nama Poli tidak boleh kosong!!")</script';
        }
        else {
          $sql = mysql_query("INSERT INTO tb_dokter values ('$kode','$nama','$adr','$telp','$kp','$kj')");
         if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=dokter_view");</script>';
         }

        }
        
    }
    ?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Create</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading"><center> Tambah Data Jadwal</center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"">
                Kode Dokter
            </label>
                <input type="text" name="kode" value="<?php echo $data['kode_dok'] ?>" class="form-control" readonly>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Nama Dokter
            </label>
                <input type="text" langht="8-12" name="nama" class="form-control" >   
            </p>
            <label class="control-label for="inputSuccess4"">
                Alamat Dokter
            </label>
                <input type="text" langht="8-12" name="alamat" class="form-control" >   
            </p>
            <label class="control-label for="inputSuccess4"">
                Telp Dokter
            </label>
                <input type="text" name="telp" class="form-control" >   
            </p>
            <label class="control-label for="inputSuccess4"">
                Kode Poli
                </p>
                    <select class="form-control" name="kode_poli" id="poli">
                        <option value=""></option>
                            <?php
                                $query_poli = mysql_query("SELECT kode_poli, nama_poli FROM tb_poliklinik");
                                while ($data = mysql_fetch_array($query_poli)) {
                                    # condition..
                                    if  ($query_pendaftaran==$data['kode_poli']) {
                                        echo "<option value=$data[kode_poli] selected>$data[kode_poli] ($data[nama_poli])</option>";
                                        # code..
                                    }
                                        # code..
                                    else{
                                        echo "<option value=$data[kode_poli] ($data[nama_poli])>$data[kode_poli] ($data[nama_poli])</option>";
                                    }
                                }
                            ?>
                    </select>
                 </p>
            <label class="control-label for="inputSuccess4"">
                Kode Jadwal
                </p>
                    <select class="form-control" name="kode_jadwal" id="jadwal">
                        <option value=""></option>
                            <?php
                                $query_scdl = mysql_query("SELECT kode_jadwal FROM tb_jadwal_praktik");
                                while ($data = mysql_fetch_array($query_scdl)) {
                                    # condition..
                                    if  ($query_pendaftaran==$data['kode_jadwal']) {
                                        echo "<option value=$data[kode_jadwal] selected>$data[kode_jadwal]</option>";
                                        # code..
                                    }
                                        # code..
                                    else{
                                        echo "<option value=$data[kode_jadwal]>$data[kode_jadwal]</option>";
                                    }
                                }
                            ?>
                    </select>
                 </p>
            <label></label>
            
            <input type="submit" name="tambah" value="Create" class=" btn btn-success">
            <a href="?page=dokter_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
    </div>
    </div>
</div>