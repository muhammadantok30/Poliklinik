<?php
include "../koneksi.php";
?>
<?php
  $query_oto = mysql_query("select max(kode_pas) as maks from tb_pasien");
  $data_oto = mysql_fetch_array($query_oto);
  $data_auto = substr($data_oto['maks'],5,5);
  $data_auto++;
  $koded="";
  for ($i=strlen($data_auto); $i <=4 ; $i++)
    $koded = $koded."0";
    $data['kode_pas'] = "PASEN$koded$data_auto";

?>
    <?php
    if (isset($_POST['tambah'])) {
        $no=$_POST['no'];
        $nama=$_POST['nama'];      
        $alamat=$_POST['alamat'];
        $tlp=$_POST['telepon'];
        $tgl=$_POST['tgl_lahir'];
        $jk=$_POST['jk'];       
        $reg=$_POST['reg'];

        $sql=mysql_query("insert into tb_pasien values ('$no','$nama', '$alamat','$tlp','$tgl','$jk', '$reg')");            
            if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=pasien_view");</script>';
            }else{
                echo'<script>alert("Data Gagal Di Tambah);</script>';           
         }
        }
    ?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Create</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading"><center> Tambah Data Pasien</center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"">
                No Pasien
            </label>
                <input type="text" name="no" class="form-control" value="<?php echo $data['kode_pas'] ?>" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Nama 
            </label>
                <input type="text" class="form-control" name="nama" required>
            </p>
            <label class="control-label for="inputSuccess4"">
                Alamat 
            </label>
                <input type="text" class="form-control" name="alamat" required>
            </p>
            <label class="control-label for="inputSuccess4"">
                Telepon 
            </label>
                <input type="number" class="form-control" name="telepon" required>
            </p>
            <label class="control-label for="inputSuccess4"">
                Tanggal Lahir 
            </label>
                <input type="date" class="form-control" placeholder="yyyy-MM-dd" name="tgl_lahir" required>
            </p>
            <label class="control-label for="inputSuccess4"">
                Pilih Jenis Kelamin 
            </label>
                <br>
                <br>
                 <input type="radio" name="jk" value="Pria" id="lakilaki" required>
                    <label for="lakilaki">Pria</label>
                <input type="radio" name="jk" value="Wanita" id="perempuan" required>
                    <label for="perempuan">wanita</label>
            </p>               
            <label class="control-label for="inputSuccess4"">
                Tanggal Reg 
            </label>
                <input type="date" class="form-control" placeholder="yyyy-MM-dd" name="reg" required>
            </p>
            <label></label>
            
            <input type="submit" name="tambah" value="Create" class=" btn btn-success">
            <a href="?page=pasien_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
    </div>
    </div>
</div>