<?php
include "../koneksi.php";
?>
    <?php
    if (isset($_POST['tambah'])) {
        $kode   =$_POST['kode_jadwal'];
        $hari   =$_POST['hari'];
        $jam1   =$_POST['jam1'];
        $jam2   =$_POST['jam2'];
        $sql=mysql_query("insert into tb_jadwal_praktik values ('$kode', '$hari', '$jam1', '$jam2')");            
            if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=jadwal_view");</script>';
            }else{
                echo'<script>alert("Data Gagal Di Tambah);</script>';           
         }
        }
    ?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Create</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading"><center> Tambah Data Jadwal</center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"">
                Kode Jadwal
            </label>
                <input type="text" name="kode_jadwal" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Hari
            </label>
                <input type="text" name="hari" class="form-control" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                jam Mulai
            </label>
                <input type="number" name="jam1" class="form-control" placeholder="hh-MM-ss" required>   
            </p>
             <label class="control-label for="inputSuccess4"">
                Jam Akhir
            </label>
                <input type="number" name="jam2" class="form-control" placeholder="hh-MM-ss" required>   
            </p>
            <label></label>
            
            <input type="submit" name="tambah" value="Create" class=" btn btn-success">
            <a href="?page=jadwal_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
    </div>
    </div>
</div>