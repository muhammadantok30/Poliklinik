<?php
include"../koneksi.php";
?>
<?php

$qry = ("SELECT * tb_pendaftaran.no_pendaftaran, tb_pasien.nama_pas, tb_obat.nama_obat, tb_obat.harga_jual, tb_resep.jumlah, tb_pemeriksaan.keluhan, tb_pemeriksaan.diagnosa, tb_pemeriksaan.perawatan, tb_rincian_resep.kode_rincian_resep, tb_jadwal_praktik.kode_jadwal, tb_jadwal_praktik.hari
FROM * tb_pendaftaran
INNER JOIN tb_pasien ON tb_pasien.kode_pas=tb_pendaftaran.kode_pas
INNER JOIN tb_resep ON tb_resep.kode_resep=tb_pemeriksaan.kode_resep
INNER JOIN tb_obat ON tb_obat.kode_obat=tb_rincian_resep.kode_obat
INNER JOIN tb_pendaftaran ON tb_pendaftaran.kode_jadwal=tb_jadwal_praktik.kode_jadwal");

?>

  <?php
    if (isset($_POST['simpan'])) {
        $kode 		=$_POST['jadwal'];
        $reg 		=$_POST['reg'];
        $nm_pas 	=$_POST['nama_pas'];
        $keluhan 	=$_POST['keluhan'];
        $diagnosa 	=$_POST['diagnosa'];
        $perawatan 	=$_POST['perawatan'];
        $kd_rsp 	=$_POST['kode_resep'];
        $nm_obat 	=$_POST['obat'];
        $dosis 		=$_POST['dosis'];
        $jumlah 	=$_POST['jumlah'];
        $harga_jual	=$_POST['harga'];
        $ttl 		=$_POST['total'];
        
       
          $sql = mysql_query("INSERT INTO tb_transaksi values ('$kode', '$reg','$nm_pas','$keluhan','$diagnosa','$perawatan','$kd_rsp','$nm_obat','$dosis','$jumlah','$harga_jual','$ttl')");
         if($sql){
            echo'<script>alert("Data Berhasil Di Tambah");
                window.location.assign("?page=pasien_view");</script>';
         }
       
    }
?>

<div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="page-header">Transaksi</h2>
                </div>
            </div>
<div class="panel panel-success">
  <div class="panel-heading">
 
  <center><h3> Data Transaksi</h3></center></div>
      <div class="panel-body"> 
      <form method="post">           
            <label class="control-label for="inputSuccess4"">
                Kode Jadwal
            </label>
                <input type="text" name="jadwal" value="<?php echo $qry['kode_jadwal'] ?>" class="form-control" readonly>   
            </p>
             <label class="control-label for="inputSuccess4"">
                No Reg
            </label>
                <input type="text" name="reg" value="<?php echo $qry['kode_jadwal'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Nama Pasien
            </label>
                <input type="text" name="nama_pas" value="<?php echo $qry['nama_pas'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Keluhan
            </label>
                <input type="text" name="keluhan" value="<?php echo $qry['keluhan'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Diagnosa
            </label>
                <input type="text" name="diagnosa" value="<?php echo $qry['diagnosa'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Perawatan
            </label>
                <input type="text" name="perawatan" value="<?php echo $qry['perawatan'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Kode Resep
            </label>
                <input type="text" name="kode_resep" value="<?php echo $qry['kode_resep'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Nama Obat
            </label>
                <input type="text" name="obat" value="<?php echo $qry['nama_obat'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Dosis
            </label>
                <input type="text" name="dosis" value="<?php echo $qry['dosis'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Jumlah
            </label>
                <input type="text" name="jumlah" value="<?php echo $qry['jumlah'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Harga Jual
            </label>
                <input type="text" name="harga" value="<?php echo $qry['harga'] ?>" class="form-control" readonly>   
            </p>
            <label class="control-label for="inputSuccess4"">
                Total Pembayaran
            </label>
                <input type="text" name="total" value="" class="form-control" readonly>   
                 <?php
                 	$harga  =	$total ['harga'];
                 	$jumlah =	$total['jumlah']; 

                 	$total = $harga * $jumlah ;
                  ?>
            </p>
            <label></label>
            
             <input type="submit" name="simpan" value="Create" class=" btn btn-success">
            <a href="?page=pasien_view"><button type="button" class="btn btn-warning">Cancel</button></a>
        </form>
    </div>
    </div>
</div>