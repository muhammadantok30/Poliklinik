<?php 
	mysql_connect("localhost", "root", "") or die("Mysql Error!!");
	mysql_select_db("db_poliklinik_ukk") or die("Databsae tidak ditemukan!");

?>